This is a simple graph plot which take csv file from googal sheet and plot.
function names : sheet_id(_id), sec_col('column_name','column_name'), plot_chart(x,y)